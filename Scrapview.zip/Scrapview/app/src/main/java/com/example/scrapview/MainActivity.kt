package com.example.scrapview

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val editTextMobile = findViewById<EditText>(R.id.editTextMobile)
        val editTextOtp = findViewById<EditText>(R.id.editTextOtp)
        val buttonSendOtp = findViewById<Button>(R.id.buttonSendOtp)
        val buttonVerifyOtp = findViewById<Button>(R.id.buttonVerifyOtp)

        buttonIngot.setOnClickListener(View.OnClickListener {
            val intent = Intent(
                this@MainActivity,
                MaterialDetailActivity::class.java
            )
            intent.putExtra("material", "ingot")
            startActivity(intent)
        })

        buttonBillet.setOnClickListener(View.OnClickListener {
            val intent = Intent(
                this@MainActivity,
                MaterialDetailActivity::class.java
            )
            intent.putExtra("material", "billet")
            startActivity(intent)
        })

        buttonPipe.setOnClickListener(View.OnClickListener {
            val intent = Intent(
                this@MainActivity,
                MaterialDetailActivity::class.java
            )
            intent.putExtra("material", "pipe")
            startActivity(intent)
        })

        buttonCastIron.setOnClickListener(View.OnClickListener {
            val intent = Intent(
                this@MainActivity,
                MaterialDetailActivity::class.java
            )
            intent.putExtra("material", "cast_iron")
            startActivity(intent)
        })

        buttonPigIron.setOnClickListener(View.OnClickListener {
            val intent = Intent(
                this@MainActivity,
                MaterialDetailActivity::class.java
            )
            intent.putExtra("material", "pig_iron")
            startActivity(intent)
        })

        buttonSpongeIron.setOnClickListener(View.OnClickListener {
            val intent = Intent(
                this@MainActivity,
                MaterialDetailActivity::class.java
            )
            intent.putExtra("material", "sponge_iron")
            startActivity(intent)
        })

        buttonIronMixScrap.setOnClickListener(View.OnClickListener {
            val intent = Intent(
                this@MainActivity,
                MaterialDetailActivity::class.java
            )
            intent.putExtra("material", "iron_mix_scrap")
            startActivity(intent)
        })

        buttonIronScrap.setOnClickListener(View.OnClickListener {
            val intent = Intent(
                this@MainActivity,
                MaterialDetailActivity::class.java
            )
            intent.putExtra("material", "iron_scrap")
            startActivity(intent)
        })

        buttonCopperScrap.setOnClickListener(View.OnClickListener {
            val intent = Intent(
                this@MainActivity,
                MaterialDetailActivity::class.java
            )
            intent.putExtra("material", "copper_scrap")
            startActivity(intent)
        })

        buttonAluminiumScrap.setOnClickListener(View.OnClickListener {
            val intent = Intent(
                this@MainActivity,
                MaterialDetailActivity::class.java
            )
            intent.putExtra("material", "aluminium_scrap")
            startActivity(intent)
        })



        buttonVerifyOtp.setOnClickListener {
            val otp = editTextOtp.text.toString()
            if (otp.length == 6) {
                // Normally: Verify OTP API here
                Toast.makeText(this, "OTP Verified!", Toast.LENGTH_SHORT).show()
                // Go to next activity
            } else {
                Toast.makeText(this, "Enter valid 6-digit OTP", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
